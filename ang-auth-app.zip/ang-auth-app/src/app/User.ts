export class User {
    name: String = '';
    email: string = '';
    password: string = '';
    mobile: number = 0;
   
}
